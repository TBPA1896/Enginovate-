import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export const courses = [
  {
    title: 'Computer Science Engineering',
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    level: 'Intermediate',
    duration: '4 Years',
    rating: 4.8,
    materials: [
      {
        semester: '1st Semester',
        subjects: [
          'Engineering Mathematics I',
          'Physics',
          'Basic Electrical Engineering',
          'Programming Fundamentals',
          'Engineering Graphics'
        ]
      },
      {
        semester: '2nd Semester',
        subjects: [
          'Engineering Mathematics II',
          'Chemistry',
          'Object-Oriented Programming',
          'Digital Electronics',
          'Professional Communication'
        ]
      },
      {
        semester: '3rd Semester',
        subjects: [
          'Data Structures',
          'Computer Organization',
          'Database Management Systems',
          'Discrete Mathematics',
          'Web Development'
        ]
      },
      {
        semester: '4th Semester',
        subjects: [
          'Operating Systems',
          'Computer Networks',
          'Software Engineering',
          'Algorithm Design',
          'Cloud Computing'
        ]
      }
    ]
  },
  {
    title: 'Mechanical Engineering',
    image: 'https://images.unsplash.com/photo-1537462715879-360eeb61a0ad?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    level: 'Intermediate',
    duration: '4 Years',
    rating: 4.7,
    materials: [
      {
        semester: '1st Semester',
        subjects: [
          'Engineering Mathematics I',
          'Engineering Physics',
          'Engineering Mechanics',
          'Manufacturing Processes',
          'Engineering Drawing'
        ]
      },
      {
        semester: '2nd Semester',
        subjects: [
          'Engineering Mathematics II',
          'Engineering Chemistry',
          'Thermodynamics',
          'Material Science',
          'Workshop Practice'
        ]
      },
      {
        semester: '3rd Semester',
        subjects: [
          'Fluid Mechanics',
          'Strength of Materials',
          'Machine Drawing',
          'Manufacturing Technology',
          'Heat Transfer'
        ]
      },
      {
        semester: '4th Semester',
        subjects: [
          'Kinematics of Machinery',
          'Applied Thermodynamics',
          'Manufacturing Automation',
          'Industrial Engineering',
          'Mechanical Measurements'
        ]
      }
    ]
  },
  {
    title: 'Electrical Engineering',
    image: 'https://images.unsplash.com/photo-1498084393753-b411b2d26b34?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    level: 'Intermediate',
    duration: '4 Years',
    rating: 4.9,
    materials: [
      {
        semester: '1st Semester',
        subjects: [
          'Engineering Mathematics I',
          'Physics',
          'Basic Electrical Engineering',
          'Electronic Devices',
          'Engineering Graphics'
        ]
      },
      {
        semester: '2nd Semester',
        subjects: [
          'Engineering Mathematics II',
          'Chemistry',
          'Circuit Theory',
          'Digital Electronics',
          'Programming Fundamentals'
        ]
      },
      {
        semester: '3rd Semester',
        subjects: [
          'Electromagnetic Theory',
          'Signals and Systems',
          'Power Electronics',
          'Electrical Measurements',
          'Control Systems'
        ]
      },
      {
        semester: '4th Semester',
        subjects: [
          'Power Systems',
          'Electrical Machines',
          'Microprocessors',
          'Communication Systems',
          'Industrial Automation'
        ]
      }
    ]
  }
];

const Courses = () => {
  const [selectedCourse, setSelectedCourse] = useState<number | null>(null);
  const [showMaterials, setShowMaterials] = useState(false);
  const navigate = useNavigate();

  const handleLearnMore = (index: number) => {
    setSelectedCourse(index);
    setShowMaterials(true);
  };

  const handleSemesterClick = (courseIndex: number, semesterNumber: number) => {
    navigate(`/course/${courseIndex}/semester/${semesterNumber}`);
  };

  return (
    <div className="py-24 bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Popular BTech Programs
          </h2>
          <p className="mt-4 text-lg text-gray-300">
            Choose from our wide range of engineering programs
          </p>
        </div>
        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {courses.map((course, index) => (
            <div
              key={index}
              className="bg-gray-900 rounded-lg overflow-hidden border border-gray-700 hover:border-blue-500 transition-all"
            >
              <div className="relative h-48">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-white">{course.title}</h3>
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-sm text-gray-400">{course.level}</span>
                  <span className="text-sm text-gray-400">{course.duration}</span>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="text-yellow-400">★</span>
                    <span className="ml-1 text-sm text-gray-300">{course.rating}</span>
                  </div>
                  <button
                    onClick={() => handleLearnMore(index)}
                    className="bg-gradient-to-r from-blue-500 to-cyan-400 text-white px-4 py-2 rounded-md text-sm hover:from-blue-600 hover:to-cyan-500"
                  >
                    View Materials
                  </button>
                </div>

                {selectedCourse === index && showMaterials && (
                  <div className="mt-6 border-t border-gray-700 pt-6">
                    <h4 className="text-lg font-semibold text-white mb-4">Course Materials</h4>
                    <div className="space-y-4">
                      {course.materials.map((material, mIndex) => (
                        <div
                          key={mIndex}
                          className="bg-gray-800 p-4 rounded-lg cursor-pointer hover:bg-gray-700 transition-all"
                          onClick={() => handleSemesterClick(index, mIndex + 1)}
                        >
                          <h5 className="text-md font-medium text-blue-400 mb-2">
                            {material.semester}
                          </h5>
                          <ul className="space-y-2">
                            {material.subjects.map((subject, sIndex) => (
                              <li
                                key={sIndex}
                                className="text-gray-300 text-sm flex items-center"
                              >
                                <span className="w-2 h-2 bg-blue-400 rounded-full mr-2"></span>
                                {subject}
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Courses;