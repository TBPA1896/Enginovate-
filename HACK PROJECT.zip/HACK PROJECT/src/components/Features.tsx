import React from 'react';
import { BookOpen, Code, Cpu, Users, LayoutDashboard, GraduationCap } from 'lucide-react';

const features = [
  {
    icon: <BookOpen className="h-6 w-6" />,
    title: 'Comprehensive Curriculum',
    description: 'Structured learning paths covering all major engineering disciplines'
  },
  {
    icon: <Code className="h-6 w-6" />,
    title: 'Practical Projects',
    description: 'Hands-on experience with real-world engineering projects'
  },
  {
    icon: <Cpu className="h-6 w-6" />,
    title: 'Latest Technology',
    description: 'Stay updated with cutting-edge engineering technologies'
  },
  {
    icon: <Users className="h-6 w-6" />,
    title: 'Expert Mentorship',
    description: 'Learn from industry professionals and experienced educators'
  },
  {
    icon: <LayoutDashboard className="h-6 w-6" />,
    title: 'Interactive Dashboard',
    description: 'Track your progress and manage your learning journey'
  },
  {
    icon: <GraduationCap className="h-6 w-6" />,
    title: 'Certification',
    description: 'Earn recognized certificates upon course completion'
  }
];

const Features = () => {
  return (
    <div className="py-24 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Why Choose Enginovate?
          </h2>
          <p className="mt-4 text-lg text-gray-300">
            Empowering BTech students with the tools and knowledge they need to succeed
          </p>
        </div>
        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div
              key={index}
              className="relative group bg-gray-800 p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-blue-500 rounded-lg border border-gray-700 hover:border-blue-500 transition-all"
            >
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-gradient-to-r from-blue-500 to-cyan-400 text-white">
                {feature.icon}
              </div>
              <div className="mt-4">
                <h3 className="text-lg font-medium text-white">{feature.title}</h3>
                <p className="mt-2 text-base text-gray-300">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Features;
