import React from 'react';
import { useNavigate } from 'react-router-dom';
import { GraduationCap } from 'lucide-react';

const Hero = () => {
  const navigate = useNavigate();

  return (
    <div className="relative bg-gradient-to-r from-gray-900 to-black overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="relative z-10">
          <div className="text-center">
            <h1 className="text-4xl tracking-tight font-extrabold text-white sm:text-5xl md:text-6x1">
              <span className="block">Transform Your Future with</span>
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">
                Engineering Excellence
              </span>
            </h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-300 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              Comprehensive BTech education platform designed to empower the next generation of engineers with cutting-edge courses, practical projects, and industry insights.
            </p>
            <div className="mt-10 flex justify-center gap-4">
              <button 
                onClick={() => document.getElementById('courses')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-gradient-to-r from-blue-500 to-cyan-400 text-white px-8 py-3 rounded-md font-medium hover:from-blue-600 hover:to-cyan-500 transition-all"
              >
                Explore Courses
              </button>
              <button 
                onClick={() => navigate('/performance')}
                className="bg-gray-800 text-gray-100 px-8 py-3 rounded-md font-medium hover:bg-gray-700 transition-all border border-gray-700"
              >
                View Performance
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80')] opacity-5"></div>
    </div>
  );
};

export default Hero;