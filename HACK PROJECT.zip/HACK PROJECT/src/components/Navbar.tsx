import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';
import { Link, useNavigate, useLocation } from 'react-router-dom';

const Navbar = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [profilePicture, setProfilePicture] = useState(''); // State for profile picture
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  useEffect(() => {
    const user = localStorage.getItem('user'); // Example of checking local storage
    if (user) {
      setIsLoggedIn(true);
      setProfilePicture('https://avatars.dicebear.com/api/initials/user.svg'); // Set the profile picture path
    } else {
      setProfilePicture('https://avatars.dicebear.com/api/initials/default.svg'); // Set the default profile picture path
    }
  }, []);

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Courses', path: '/#courses' },
    { name: 'Performance', path: '/performance' },
    { name: 'Resources', path: '/#resources' },
    { name: 'About', path: '/#about' },
  ];

  const handleNavigation = (path: string) => {
    setIsMenuOpen(false);
    if (path.startsWith('/#')) {
      if (location.pathname === '/') {
        document.getElementById(path.substring(2))?.scrollIntoView({ behavior: 'smooth' });
      } else {
        navigate('/');
        setTimeout(() => {
          document.getElementById(path.substring(2))?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    } else {
      navigate(path);
    }
  };

  return (
    <nav className="bg-gray-800 border-b border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Link to="/" className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
                Enginovate
              </Link>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavigation(item.path)}
                className={`text-gray-300 hover:text-blue-400 transition-colors ${
                  location.pathname === item.path ? 'text-blue-400' : ''
                }`}
              >
                {item.name}
              </button>
            ))}
            <div className="relative">
              <img 
                src={profilePicture} // Use the profile picture state
                alt="Profile"
                className="w-8 h-8 rounded-full cursor-pointer"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              />
              <ChevronDown 
                className="text-gray-300 cursor-pointer ml-2"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              />
              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20">
                  {isLoggedIn ? (
                    <>
                      <Link to="/UserProfile" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                        Profile
                      </Link>
                      <button 
                        onClick={() => {
                          localStorage.removeItem('user');
                          setIsLoggedIn(false);
                          setIsDropdownOpen(false);
                          navigate('/SignIn');
                        }}
                        className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                      >
                        Sign Out
                      </button>
                    </>
                  ) : (
                    <button 
                      onClick={() => {
                        setIsDropdownOpen(false);
                        navigate('/SignIn');
                      }}
                      className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                    >
                      Sign In
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
          <div className="md:hidden flex items-center">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-300 hover:text-white"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-gray-800 border-t border-gray-700">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavigation(item.path)}
                className="block w-full text-left px-3 py-2 text-gray-300 hover:text-blue-400 hover:bg-gray-700 rounded-md"
              >
                {item.name}
              </button>
            ))}
            <div className="relative">
              <img 
                src={profilePicture} // Use the profile picture state
                alt="Profile"
                className="w-8 h-8 rounded-full cursor-pointer"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              />
              <ChevronDown 
                className="text-gray-300 cursor-pointer ml-2"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              />
              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20">
                  {isLoggedIn ? (
                    <>
                      <Link to="/UserProfile" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                        Profile
                      </Link>
                      <button 
                        onClick={() => {
                          localStorage.removeItem('user');
                          setIsLoggedIn(false);
                          setIsDropdownOpen(false);
                          navigate('/SignIn');
                        }}
                        className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                      >
                        Sign Out
                      </button>
                    </>
                  ) : (
                    <button 
                      onClick={() => {
                        setIsDropdownOpen(false);
                        navigate('/SignIn');
                      }}
                      className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                    >
                      Sign In
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
