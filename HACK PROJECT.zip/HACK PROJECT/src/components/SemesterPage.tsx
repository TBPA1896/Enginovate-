import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Book, Clock, GraduationCap, Users, BookOpen, Brain } from 'lucide-react';
import { courses } from './Courses';

interface SubjectDetails {
  name: string;
  description: string;
  credits: number;
  duration: string;
  prerequisites: string[];
  learningOutcomes: string[];
}

const subjectDetails: Record<string, SubjectDetails> = {
  'Engineering Mathematics I': {
    name: 'Engineering Mathematics I',
    description: 'Fundamental mathematical concepts including calculus, linear algebra, and differential equations.',
    credits: 4,
    duration: '60 hours',
    prerequisites: ['Basic Mathematics'],
    learningOutcomes: [
      'Understanding of calculus and its applications',
      'Ability to solve linear equations and matrices',
      'Knowledge of differential equations'
    ]
  },
  'Physics': {
    name: 'Physics',
    description: 'Basic principles of physics including mechanics, waves, and thermodynamics.',
    credits: 4,
    duration: '60 hours',
    prerequisites: ['Basic Physics'],
    learningOutcomes: [
      'Understanding of mechanical principles',
      'Knowledge of wave mechanics',
      'Comprehension of thermodynamic laws'
    ]
  },
  // Add more subject details as needed
};

const SemesterPage = () => {
  const { courseId, semesterId } = useParams();
  const navigate = useNavigate();
  
  const course = courses[Number(courseId)];
  const semester = course?.materials.find(m => m.semester === `${semesterId}st Semester` || m.semester === `${semesterId}nd Semester` || m.semester === `${semesterId}rd Semester` || m.semester === `${semesterId}th Semester`);

  if (!course || !semester) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Course or Semester not found</h2>
          <button
            onClick={() => navigate('/')}
            className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600"
          >
            Go Back Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="py-12 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-white mb-2">{course.title}</h1>
          <h2 className="text-2xl text-blue-400">{semester.semester}</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {semester.subjects.map((subject, index) => {
            const details = subjectDetails[subject] || {
              name: subject,
              description: 'Detailed description coming soon.',
              credits: 3,
              duration: '60 hours',
              prerequisites: ['Basic knowledge in the field'],
              learningOutcomes: ['Understanding core concepts', 'Practical application skills']
            };

            return (
              <div key={index} className="bg-gray-800 rounded-lg overflow-hidden border border-gray-700 hover:border-blue-500 transition-all">
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <BookOpen className="h-6 w-6 text-blue-400" />
                    <h3 className="ml-2 text-xl font-semibold text-white">{details.name}</h3>
                  </div>
                  
                  <p className="text-gray-300 mb-4">{details.description}</p>
                  
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <GraduationCap className="h-5 w-5 text-gray-400" />
                      <span className="ml-2 text-gray-300">{details.credits} Credits</span>
                    </div>
                    
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-gray-400" />
                      <span className="ml-2 text-gray-300">{details.duration}</span>
                    </div>
                  </div>

                  <div className="mt-6">
                    <h4 className="text-lg font-semibold text-white mb-2">Prerequisites</h4>
                    <ul className="list-disc list-inside text-gray-300 space-y-1">
                      {details.prerequisites.map((prereq, idx) => (
                        <li key={idx}>{prereq}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="mt-6">
                    <h4 className="text-lg font-semibold text-white mb-2">Learning Outcomes</h4>
                    <ul className="list-disc list-inside text-gray-300 space-y-1">
                      {details.learningOutcomes.map((outcome, idx) => (
                        <li key={idx}>{outcome}</li>
                      ))}
                    </ul>
                  </div>

                  <button className="mt-6 w-full bg-gradient-to-r from-blue-500 to-cyan-400 text-white px-4 py-2 rounded-md hover:from-blue-600 hover:to-cyan-500 transition-all">
                    View Course Material
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default SemesterPage;