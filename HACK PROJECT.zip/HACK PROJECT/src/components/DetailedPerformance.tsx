import React, { useState } from 'react';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis
} from 'recharts';
import { Brain, TrendingUp, Award, Clock, BookOpen, Target, ChevronDown, ChevronUp, AlertCircle } from 'lucide-react';

const performanceData = [
  { month: 'Jan', score: 75, attendance: 85, assignments: 80, practicals: 78 },
  { month: 'Feb', score: 82, attendance: 88, assignments: 85, practicals: 83 },
  { month: 'Mar', score: 78, attendance: 90, assignments: 82, practicals: 85 },
  { month: 'Apr', score: 85, attendance: 92, assignments: 88, practicals: 87 },
  { month: 'May', score: 90, attendance: 95, assignments: 92, practicals: 91 },
];

const skillsData = [
  { subject: 'Problem Solving', score: 80 },
  { subject: 'Technical Skills', score: 85 },
  { subject: 'Communication', score: 75 },
  { subject: 'Team Work', score: 90 },
  { subject: 'Project Management', score: 70 },
  { subject: 'Innovation', score: 85 },
];

const subjectPerformance = [
  { subject: 'Data Structures', score: 85, improvement: 12, status: 'improving' },
  { subject: 'Algorithms', score: 78, improvement: -5, status: 'declining' },
  { subject: 'Database Systems', score: 92, improvement: 8, status: 'improving' },
  { subject: 'Web Development', score: 88, improvement: 15, status: 'improving' },
  { subject: 'Computer Networks', score: 75, improvement: 3, status: 'stable' },
];

const learningPatterns = [
  { time: '6 AM', efficiency: 65 },
  { time: '9 AM', efficiency: 85 },
  { time: '12 PM', efficiency: 75 },
  { time: '3 PM', efficiency: 70 },
  { time: '6 PM', efficiency: 80 },
  { time: '9 PM', efficiency: 60 },
];

const DetailedPerformance = () => {
  const [selectedMetric, setSelectedMetric] = useState('score');
  const [showRecommendations, setShowRecommendations] = useState(true);

  return (
    <div className="py-12 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-white mb-2">AI Performance Analytics</h1>
          <p className="text-gray-400">Comprehensive analysis of your academic performance</p>
        </div>

        {/* Overall Performance Score */}
        <div className="bg-gray-800 rounded-lg p-6 mb-8 border border-gray-700">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-white">Overall Performance Score</h2>
              <p className="text-gray-400">Based on multiple performance indicators</p>
            </div>
            <div className="text-4xl font-bold text-blue-400">85%</div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1F2937',
                    border: '1px solid #374151',
                    borderRadius: '0.375rem',
                  }}
                  labelStyle={{ color: '#F9FAFB' }}
                />
                <Legend />
                <Line type="monotone" dataKey="score" stroke="#3B82F6" strokeWidth={2} />
                <Line type="monotone" dataKey="attendance" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="assignments" stroke="#F59E0B" strokeWidth={2} />
                <Line type="monotone" dataKey="practicals" stroke="#8B5CF6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Skills Assessment */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-6">Skills Assessment</h2>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={skillsData}>
                  <PolarGrid stroke="#374151" />
                  <PolarAngleAxis dataKey="subject" stroke="#9CA3AF" />
                  <PolarRadiusAxis stroke="#9CA3AF" />
                  <Radar
                    name="Skills"
                    dataKey="score"
                    stroke="#3B82F6"
                    fill="#3B82F6"
                    fillOpacity={0.3}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Learning Pattern Analysis */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-6">Learning Pattern Analysis</h2>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={learningPatterns}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="time" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1F2937',
                      border: '1px solid #374151',
                      borderRadius: '0.375rem',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="efficiency"
                    stroke="#8B5CF6"
                    fill="#8B5CF6"
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Subject-wise Performance */}
        <div className="bg-gray-800 rounded-lg p-6 mb-8 border border-gray-700">
          <h2 className="text-xl font-bold text-white mb-6">Subject-wise Performance</h2>
          <div className="space-y-4">
            {subjectPerformance.map((subject, index) => (
              <div
                key={index}
                className="bg-gray-700 rounded-lg p-4 flex items-center justify-between"
              >
                <div>
                  <h3 className="text-white font-medium">{subject.subject}</h3>
                  <div className="flex items-center mt-1">
                    {subject.status === 'improving' ? (
                      <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
                    ) : subject.status === 'declining' ? (
                      <ChevronDown className="w-4 h-4 text-red-400 mr-1" />
                    ) : (
                      <ChevronUp className="w-4 h-4 text-yellow-400 mr-1" />
                    )}
                    <span
                      className={`text-sm ${
                        subject.status === 'improving'
                          ? 'text-green-400'
                          : subject.status === 'declining'
                          ? 'text-red-400'
                          : 'text-yellow-400'
                      }`}
                    >
                      {subject.improvement > 0 ? '+' : ''}
                      {subject.improvement}%
                    </span>
                  </div>
                </div>
                <div className="text-2xl font-bold text-blue-400">{subject.score}%</div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Brain className="w-6 h-6 text-blue-400 mr-2" />
              <h2 className="text-xl font-bold text-white">AI Recommendations</h2>
            </div>
            <button
              onClick={() => setShowRecommendations(!showRecommendations)}
              className="text-gray-400 hover:text-white"
            >
              {showRecommendations ? <ChevronUp /> : <ChevronDown />}
            </button>
          </div>
          {showRecommendations && (
            <div className="space-y-4">
              <div className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-start">
                  <Target className="w-5 h-5 text-green-400 mt-1 mr-2" />
                  <div>
                    <h3 className="text-white font-medium">Focus Areas</h3>
                    <p className="text-gray-300 mt-1">
                      Increase practice time for Algorithms to improve performance. Current trend shows room for improvement.
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-start">
                  <Clock className="w-5 h-5 text-blue-400 mt-1 mr-2" />
                  <div>
                    <h3 className="text-white font-medium">Study Schedule</h3>
                    <p className="text-gray-300 mt-1">
                      Your learning efficiency peaks between 9 AM and 12 PM. Consider scheduling complex topics during these hours.
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-start">
                  <AlertCircle className="w-5 h-5 text-yellow-400 mt-1 mr-2" />
                  <div>
                    <h3 className="text-white font-medium">Action Items</h3>
                    <ul className="text-gray-300 mt-1 space-y-2">
                      <li>• Join the Advanced Algorithms study group</li>
                      <li>• Complete the pending practical assignments</li>
                      <li>• Review Database Systems concepts before the next assessment</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DetailedPerformance;