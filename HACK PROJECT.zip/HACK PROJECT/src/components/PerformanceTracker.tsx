import React, { useState } from 'react';
import { Brain, TrendingUp, Award, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

// Mock data for demonstration
const performanceData = [
  { month: 'Jan', score: 75, attendance: 85, assignments: 80 },
  { month: 'Feb', score: 82, attendance: 88, assignments: 85 },
  { month: 'Mar', score: 78, attendance: 90, assignments: 82 },
  { month: 'Apr', score: 85, attendance: 92, assignments: 88 },
  { month: 'May', score: 90, attendance: 95, assignments: 92 },
];

const insights = [
  {
    title: 'Performance Trend',
    description: 'Showing consistent improvement in test scores',
    icon: <TrendingUp className="w-6 h-6 text-blue-400" />,
    metric: '+15%'
  },
  {
    title: 'Learning Pattern',
    description: 'Strong understanding of core concepts',
    icon: <Brain className="w-6 h-6 text-cyan-400" />,
    metric: '92%'
  },
  {
    title: 'Achievement',
    description: 'Top 10% in class ranking',
    icon: <Award className="w-6 h-6 text-yellow-400" />,
    metric: 'Top 10%'
  },
  {
    title: 'Study Hours',
    description: 'Consistent study pattern observed',
    icon: <Clock className="w-6 h-6 text-green-400" />,
    metric: '25hrs/week'
  }
];

const PerformanceTracker = () => {
  const [selectedMetric, setSelectedMetric] = useState('score');
  const navigate = useNavigate();

  return (
    <div className="py-24 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            AI Performance Analytics
          </h2>
          <p className="mt-4 text-lg text-gray-300">
            Track your progress with our advanced AI-powered analytics
          </p>
          <button
            onClick={() => navigate('/performance')}
            className="mt-4 bg-gradient-to-r from-blue-500 to-cyan-400 text-white px-6 py-2 rounded-md hover:from-blue-600 hover:to-cyan-500 transition-all"
          >
            View Detailed Analysis
          </button>
        </div>

        {/* Performance Insights */}
        <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {insights.map((insight, index) => (
            <div
              key={index}
              className="bg-gray-800 p-6 rounded-lg border border-gray-700 hover:border-blue-500 transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  {insight.icon}
                  <h3 className="ml-3 text-lg font-medium text-white">{insight.title}</h3>
                </div>
                <span className="text-xl font-semibold text-blue-400">{insight.metric}</span>
              </div>
              <p className="mt-2 text-gray-400">{insight.description}</p>
            </div>
          ))}
        </div>

        {/* Performance Graph */}
        <div className="mt-12 bg-gray-800 p-6 rounded-lg border border-gray-700">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-white">Performance Trends</h3>
            <div className="flex gap-4">
              <button
                onClick={() => setSelectedMetric('score')}
                className={`px-4 py-2 rounded-md ${
                  selectedMetric === 'score'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-700 text-gray-300'
                }`}
              >
                Test Scores
              </button>
              <button
                onClick={() => setSelectedMetric('attendance')}
                className={`px-4 py-2 rounded-md ${
                  selectedMetric === 'attendance'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-700 text-gray-300'
                }`}
              >
                Attendance
              </button>
              <button
                onClick={() => setSelectedMetric('assignments')}
                className={`px-4 py-2 rounded-md ${
                  selectedMetric === 'assignments'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-700 text-gray-300'
                }`}
              >
                Assignments
              </button>
            </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1F2937',
                    border: '1px solid #374151',
                    borderRadius: '0.375rem',
                  }}
                  labelStyle={{ color: '#F9FAFB' }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey={selectedMetric}
                  stroke="#60A5FA"
                  strokeWidth={2}
                  dot={{ fill: '#60A5FA' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="mt-12 bg-gray-800 p-6 rounded-lg border border-gray-700">
          <div className="flex items-center">
            <Brain className="w-8 h-8 text-blue-400" />
            <h3 className="ml-3 text-xl font-semibold text-white">AI Recommendations</h3>
          </div>
          <div className="mt-6 space-y-4">
            <div className="p-4 bg-gray-700 rounded-lg">
              <p className="text-gray-200">
                Based on your recent performance, focus on improving your problem-solving skills in
                Data Structures.
              </p>
            </div>
            <div className="p-4 bg-gray-700 rounded-lg">
              <p className="text-gray-200">
                Your consistency in attending classes has positively impacted your test scores.
                Keep it up!
              </p>
            </div>
            <div className="p-4 bg-gray-700 rounded-lg">
              <p className="text-gray-200">
                Consider joining the Advanced Algorithms study group to enhance your understanding
                of complex topics.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceTracker;