import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const SignIn = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Added state for login status
  const navigate = useNavigate();


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Validate email and password
    if (email === 'admin@admin' && password === 'admin') {
      console.log('Sign In:', { email, password });
      // Navigate to a different page after sign-in
      setIsLoggedIn(true); // Set login state
      navigate('/'); // Navigate to home page after login



    } else {
      alert('Invalid email or password');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      <form onSubmit={handleSubmit} className="bg-gray-800 p-8 rounded-md shadow-md">
        <h2 className="text-2xl text-white mb-4">Sign In</h2>
        <div className="mb-4">
          <label className="block text-gray-300 mb-1" htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-2 rounded-md"
            required
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-300 mb-1" htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-2 rounded-md"
            required
          />
        </div>
        {isLoggedIn ? (
          <button 
            onClick={() => navigate('/userprofile')}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-400 text-white px-4 py-2 rounded-md hover:from-blue-600 hover:to-cyan-500"
          >
            User Profile
          </button>
        ) : (
          <button type="submit" className="w-full bg-gradient-to-r from-blue-500 to-cyan-400 text-white px-4 py-2 rounded-md hover:from-blue-600 hover:to-cyan-500">
            Sign In
          </button>
        )}
        <button 
          onClick={() => navigate('/signup')}
          className="w-full bg-gradient-to-r from-green-500 to-lime-400 text-white px-4 py-2 rounded-md hover:from-green-600 hover:to-lime-500 mt-4"
        >
          Sign Up
        </button>
      </form>
    </div>
  );
};

export default SignIn;
