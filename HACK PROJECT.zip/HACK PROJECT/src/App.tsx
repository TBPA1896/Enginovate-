import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Courses from './components/Courses';
import PerformanceTracker from './components/PerformanceTracker';
import DetailedPerformance from './components/DetailedPerformance';
import Footer from './components/Footer';
import SemesterPage from './components/SemesterPage';
import SignIn from './components/SignIn';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-900">
        <Navbar />
        <Routes>
          <Route path="/" element={
            <>
              <Hero />
              <Features />
              <Courses />
              <PerformanceTracker />
            </>
          } />
          <Route path="/course/:courseId/semester/:semesterId" element={<SemesterPage />} />
          <Route path="/performance" element={<DetailedPerformance />} />
          <Route path="/signin" element={<SignIn />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
